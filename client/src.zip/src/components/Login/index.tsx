import { LoginForm } from './LoginForm'
import type { LoginProps } from './types'

export function Login({ onLogin }: LoginProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
      <div className="w-full max-w-md px-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">JANATICS</h1>
          <p className="text-slate-400">Component Development Requisition System</p>
        </div>
        <LoginForm onLogin={onLogin} />
      </div>
    </div>
  )
}
