import React from "react";
import { UseFormRegister } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RequisitionFormData } from "./types";

interface FormMetaProps {
  register: UseFormRegister<RequisitionFormData>;
}

export const FormMeta: React.FC<FormMetaProps> = ({ register }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 border rounded-lg bg-card shadow-sm">
      <div className="space-y-1.5">
        <Label htmlFor="recNo" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Rec. No.</Label>
        <Input id="recNo" {...register("recNo")} className="h-9 font-mono" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="date" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</Label>
        <Input id="date" type="date" {...register("date")} className="h-9" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="pageNo" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Page No.</Label>
        <Input id="pageNo" {...register("pageNo")} className="h-9" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="from" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">From (D&D Team)</Label>
        <Input id="from" {...register("from")} className="h-9" />
      </div>
      <div className="space-y-1.5 col-span-2 md:col-span-1">
        <Label htmlFor="to" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">To (Materials-D&D)</Label>
        <Input id="to" {...register("to")} className="h-9" />
      </div>
    </div>
  );
};
