import React from "react";
import { UseFormRegister } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RequisitionFormData } from "./types";

interface SignaturesProps {
  register: UseFormRegister<RequisitionFormData>;
}

export const Signatures: React.FC<SignaturesProps> = ({ register }) => {
  const roles = [
    { key: "prepared", label: "Prepared By" },
    { key: "checked", label: "Checked By" },
    { key: "approved", label: "Approved By" },
    { key: "received", label: "Received By (Materials)" }
  ] as const;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 border rounded-lg bg-muted/20">
      {roles.map((role) => (
        <div key={role.key} className="space-y-2 p-3 border rounded bg-card shadow-sm">
          <Label className="text-xs font-bold uppercase text-foreground/80">{role.label}</Label>
          <div className="space-y-1">
            <Input 
              {...register(`signatures.${role.key}.name` as const)} 
              placeholder="Name" 
              className="h-8 text-xs font-medium"
            />
            <Input 
              {...register(`signatures.${role.key}.date` as const)} 
              placeholder="Signature Date"
              className="h-8 text-[11px] text-muted-foreground font-mono"
            />
          </div>
        </div>
      ))}
    </div>
  );
};
