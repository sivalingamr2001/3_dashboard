import React from "react";
import { UseFormRegister, useFieldArray, Control } from "react-hook-form";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RequisitionFormData } from "./types";

interface PartTableProps {
  register: UseFormRegister<RequisitionFormData>;
  control: Control<RequisitionFormData>;
}

export const PartTable: React.FC<PartTableProps> = ({ register, control }) => {
  const { fields, append, remove } = useFieldArray({
    control,
    name: "parts"
  });

  return (
    <div className="space-y-4 border rounded-lg p-4 bg-card shadow-sm">
      <div className="flex justify-between items-center">
        <h3 className="text-sm font-semibold tracking-wide text-foreground uppercase">Component Breakdown List</h3>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => append({ sNo: fields.length + 1, partNo: "", rev: "", partName: "", qty: 1, requiredDate: "", committedDate: "", actualCompletionDate: "" })}
        >
          + Add Row
        </Button>
      </div>

      <div className="overflow-x-auto border rounded-md">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-12 text-center text-xs">S.No</TableHead>
              <TableHead className="w-36 text-xs">Part No</TableHead>
              <TableHead className="w-16 text-xs">Rev</TableHead>
              <TableHead className="text-xs">Part Name</TableHead>
              <TableHead className="w-20 text-xs">Qty</TableHead>
              <TableHead className="w-36 text-xs">Required Date</TableHead>
              <TableHead className="w-36 text-xs">Committed Date</TableHead>
              <TableHead className="w-16 text-center text-xs">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {fields.map((field, index) => (
              <TableRow key={field.id}>
                <TableCell className="text-center font-mono text-sm">{index + 1}</TableCell>
                <TableCell><Input {...register(`parts.${index}.partNo` as const)} className="h-8 font-mono text-xs" /></TableCell>
                <TableCell><Input {...register(`parts.${index}.rev` as const)} className="h-8 font-mono text-xs text-center" /></TableCell>
                <TableCell><Input {...register(`parts.${index}.partName` as const)} className="h-8 text-xs" /></TableCell>
                <TableCell><Input type="number" {...register(`parts.${index}.qty` as const)} className="h-8 text-xs" /></TableCell>
                <TableCell><Input type="date" {...register(`parts.${index}.requiredDate` as const)} className="h-8 text-xs" /></TableCell>
                <TableCell><Input type="date" {...register(`parts.${index}.committedDate` as const)} className="h-8 text-xs" /></TableCell>
                <TableCell className="text-center">
                  <Button type="button" variant="ghost" className="h-7 w-7 text-destructive hover:text-destructive/90 p-0" onClick={() => remove(index)}>
                    ✕
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {fields.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-6 text-muted-foreground text-xs">
                  No components added yet. Click Add Row to break down the requisition.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      <div className="bg-amber-500/10 border border-amber-500/30 rounded p-3 text-[11px] text-amber-600 dark:text-amber-400 font-medium leading-relaxed">
        ⚠️ **Note on Minimum Order Quantity (MOQ):** For raw materials/components that carry high commercial minimum ordering margins, development tracking profiles remain bound to vendor availability limits.
      </div>
    </div>
  );
};
