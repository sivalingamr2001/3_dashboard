import React from "react";
import { CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

interface FormHeaderProps {
  onAutoPopulate: () => void;
  isLoading: boolean;
}

export const FormHeader: React.FC<FormHeaderProps> = ({ onAutoPopulate, isLoading }) => {
  return (
    <CardHeader className="border-b bg-muted/30 pb-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <CardTitle className="text-xl font-bold tracking-tight text-primary">
            JANATICS - REQUISITION FOR COMPONENT DEVELOPMENT
          </CardTitle>
          <CardDescription className="text-xs font-mono mt-1">
            Form No: F/D&D/21 | Issue No: 4.2
          </CardDescription>
        </div>
        <button
          type="button"
          onClick={onAutoPopulate}
          disabled={isLoading}
          className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring bg-primary text-primary-foreground shadow hover:bg-primary/90 h-9 px-4 py-2"
        >
          {isLoading ? "Fetching Data..." : "⚡ Auto-Populate Form Data"}
        </button>
      </div>
    </CardHeader>
  );
};
