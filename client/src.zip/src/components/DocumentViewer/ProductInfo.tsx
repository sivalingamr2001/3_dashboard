import React from "react";
import { UseFormRegister, Control, Controller } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RequisitionFormData } from "./types";

interface ProductInfoProps {
  register: UseFormRegister<RequisitionFormData>;
  control: Control<RequisitionFormData>;
}

export const ProductInfo: React.FC<ProductInfoProps> = ({ register, control }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-5 border rounded-lg bg-card shadow-sm">
      <div className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="productNo" className="text-xs font-semibold uppercase text-muted-foreground">Product No.</Label>
          <Input id="productNo" {...register("productNo")} className="h-9" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rev" className="text-xs font-semibold uppercase text-muted-foreground">Revision</Label>
          <Input id="rev" {...register("rev")} className="h-9 font-mono" />
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="projectNo" className="text-xs font-semibold uppercase text-muted-foreground">Project No.</Label>
          <Input id="projectNo" {...register("projectNo")} className="h-9" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="productName" className="text-xs font-semibold uppercase text-muted-foreground">Product Name</Label>
          <Input id="productName" {...register("productName")} className="h-9" />
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="purpose" className="text-xs font-semibold uppercase text-muted-foreground">Purpose</Label>
          <Controller
            name="purpose"
            control={control}
            render={({ field }) => (
              <Select onValueChange={field.onChange} value={field.value || ""}>
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select purpose..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="New product validation">New product validation</SelectItem>
                  <SelectItem value="Sales Requirement">Sales Requirement</SelectItem>
                  <SelectItem value="Design Optimization">Design Optimization</SelectItem>
                </SelectContent>
              </Select>
            )}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="monthlyQty" className="text-xs font-semibold uppercase text-muted-foreground">Est. Monthly Quantity</Label>
          <Input id="monthlyQty" {...register("monthlyQty")} className="h-9" placeholder="As per new product req." />
        </div>
      </div>
    </div>
  );
};
