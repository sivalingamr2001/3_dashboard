import { Loader } from "@/components/Loader"
import { AppLayout } from "@/layout/AppLayout"
import { AuthLayout } from "@/layout/AuthLayout"
import { lazy, Suspense } from "react"
import { Route, Routes } from "react-router-dom"

const DashboardPage = lazy(() =>
  import("@/pages/DashboardPage").then((module) => ({
    default: module.DashboardPage,
  }))
)
const LoginPage = lazy(() =>
  import("@/pages/LoginPage").then((module) => ({ default: module.LoginPage }))
)

export const Router = () => {
  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/" element={<AuthLayout />}>
          <Route path="/login" element={<LoginPage />} />
        </Route>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<DashboardPage />} />
        </Route>
      </Routes>
    </Suspense>
  )
}
