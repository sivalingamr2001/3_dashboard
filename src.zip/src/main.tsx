import { createRoot } from "react-dom/client"

import { ThemeProvider } from "@/context/theme-provider.tsx"
import { BrowserRouter } from "react-router-dom"
import { Toaster } from 'sonner'
import App from "./App.tsx"
import { TooltipProvider } from "./components/ui/tooltip.tsx"
import { CommodityProvider } from "./context/CommodityProvider.tsx"
import "./index.css"

createRoot(document.getElementById("root")!).render(
  <>
    <TooltipProvider>
      <ThemeProvider>
        <BrowserRouter basename="/pes_lite/">
          <Toaster position="top-right" richColors />
          <CommodityProvider>
            <App />
          </CommodityProvider>
        </BrowserRouter>
      </ThemeProvider>
    </TooltipProvider>
  </>
)
