import React from 'react';
import { ArrowLeft, ChevronRight, Cpu, Bell, House } from 'lucide-react';

interface AppHeaderProps {
  onHomeClick?: () => void;
  onAlertsClick?: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({ onHomeClick, onAlertsClick }) => {
  return (
    <div
      className="flex items-center gap-3 px-5 py-2.5 shrink-0 select-none"
      style={{ background: 'linear-gradient(135deg, rgb(76, 29, 149) 0%, rgb(124, 58, 237) 100%)' }}
    >
      <button
        className="flex shrink-0 items-center gap-1 rounded-full p-1.5 text-slate-400 transition-colors hover:bg-blue-50 hover:text-blue-600"
        title="Home"
        onClick={onHomeClick}
      >
        <House className="h-4 w-4" />
      </button>

      {/* Breadcrumb Separator */}
      <ChevronRight size={11} strokeWidth={2} className="text-violet-400" />

      {/* App Logo/Icon */}
      <Cpu size={15} strokeWidth={2} className="text-violet-300" />

      {/* Title & Subtitle */}
      <div>
        <div className="text-white font-black text-[13px] leading-tight">
          Commodity Custodian
        </div>
        <div className="text-violet-300 text-[10px]">
          Component &amp; Vendor Management
        </div>
      </div>

      {/* Right-aligned Stats & Controls */}
      <div className="ml-auto flex items-center gap-2.5">

        {/* Metric Badges */}
        <div className="flex gap-1.5">
          <span className="text-[9px] font-black px-1.5 py-0.5 rounded border bg-red-100 text-red-700 border-red-300">
            T1a: 7
          </span>
          <span className="text-[9px] font-black px-1.5 py-0.5 rounded border bg-amber-100 text-amber-700 border-amber-300">
            T1b: 7
          </span>
          <span className="text-[9px] font-black px-1.5 py-0.5 rounded border bg-slate-100 text-slate-600 border-slate-300">
            T2: 8
          </span>
        </div>

        {/* Date Display */}
        <span className="text-[9px] text-violet-300 font-mono">
          Wed, 29 Jul, 2026
        </span>

        {/* Alerts Action Button
        <button
          onClick={onAlertsClick}
          className="relative flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-colors"
        >
          <Bell size={11} strokeWidth={2} />
          Alerts
          <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 border border-white text-[7px] font-black flex items-center justify-center">
            4
          </span>
        </button> */}

      </div>
    </div>
  );
};
