import type { PesConsolidatedData } from "@/api/pesApi"
import { Badge } from "@/components/ui/badge"
import type { ColDef, RowClassParams } from "ag-grid-community"
import {
  AllCommunityModule,
  ModuleRegistry,
  themeMaterial
} from "ag-grid-community"
import { AgGridReact } from "ag-grid-react"
import { Shield, ShieldAlert } from "lucide-react"
import { useMemo } from "react"

ModuleRegistry.registerModules([AllCommunityModule])

interface Props {
  items: PesConsolidatedData[]
  onRowClick?: (item: PesConsolidatedData) => void
  onFilterChange?: (custodianName: string | null) => void
}

const fmt = (n: number | null) =>
  n === null || n === undefined ? <span className="text-slate-300">—</span> : n.toLocaleString()

export const ItemTable = ({ items, onRowClick, onFilterChange }: Props) => {
  const customTheme = useMemo(() => {
    return themeMaterial.withParams({
      borderColor: "transparent",
      headerBackgroundColor: "#F8FAFC",
      fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    })
  }, [])

  const columnDefs = useMemo<ColDef<PesConsolidatedData>[]>(
    () => [
      {
        headerName: "ORG",
        field: "ORG",
        filter: true,
        width: 100, // Reduced from 100 to 70 to make it compact
        flex: 1, // Reduced flex proportion
        cellClassName: "font-semibold tracking-tight text-slate-800 pl-5 pr-2 py-2 text-[11px] flex items-center",
        headerClass: "pl-5 pr-2 py-2",
      },
      {
        headerName: "Item Code",
        field: "ORDERED_ITEM",
        minWidth: 140,
        flex: 1.5,
        filter: true,
        cellClassName: "font-semibold tracking-tight text-slate-800 pl-5 pr-2 py-2 text-[11px] flex items-center",
        headerClass: "pl-5 pr-2 py-2",
      },
      {
        headerName: "Description",
        field: "DESCRIPTION",
        minWidth: 110, // ~15 characters fallback space (using 110px based on 11px font size)
        flex: 3,
        filter: true,
        cellClassName: "font-medium text-slate-500 px-3 py-2 text-[11px] truncate flex items-center",
        headerClass: "px-3 py-2",
        cellRenderer: (params: any) => (
          <span className="block line-clamp-15 wrap-break-word" title={params.value}>
            {params.value?.trim() || <span className="text-slate-300">—</span>}
          </span>
        ),
      },
      {
        headerName: "Custodian Name",
        field: "CUSTODIAN_NAME",
        minWidth: 110,
        flex: 3,
        filter: true,
        cellClassName: "font-medium text-slate-500 px-3 py-2 text-[11px] truncate flex items-center",
        headerClass: "px-3 py-2",
        cellRenderer: (params: any) => (
          <span className="block line-clamp-15 wrap-break-word" title={params.value}>
            {params.value?.trim() || <span className="text-slate-300">—</span>}
          </span>
        ),
      },
      {
        headerName: "Type",
        field: "AMS_CAT",
        width: 100,
        cellClassName: "px-2 py-2 flex items-center justify-start",
        headerClass: "px-2 py-2",
        cellRenderer: (params: any) => {
          const isAms1 = params.value === "AMS1" || params.value === "AMS-1";
          return (
            <Badge
              variant="outline"
              className={`rounded-[4px] border-none px-2 py-0.5 text-[9px] font-bold tracking-wide shadow-none ${isAms1 ? "bg-blue-50 text-blue-600" : "bg-purple-50 text-purple-600"
                }`}
            >
              {isAms1 ? "AMS1" : "AMS2"}
            </Badge>
          );
        },
      },
      {
        headerName: "Req Qty",
        field: "REQ_QTY",
        width: 110,
        type: "numericColumn",
        cellClassName: "px-4 py-2 text-right font-medium text-slate-700 text-[11px] flex items-center justify-end",
        headerClass: "px-4 py-2 text-right",
        cellRenderer: (params: any) => fmt(params.value),
      },
      {
        headerName: "Exception Qty",
        field: "EXCEPTION_QTY",
        width: 130,
        type: "numericColumn",
        cellClassName: "px-4 py-2 text-right font-medium text-slate-700 text-[11px] flex items-center justify-end",
        headerClass: "px-4 py-2 text-right",
        cellRenderer: (params: any) => fmt(params.value),
      },
      {
        headerName: "Constraint",
        field: "CONSTRAINT",
        minWidth: 150,
        flex: 2,
        cellClassName: "py-2 pr-5 pl-2 flex items-center gap-1 text-[11px]",
        headerClass: "py-2 pr-5 pl-2",
        cellRenderer: (params: any) => {
          const isConstrained = params.value === "CONSTRAINT" || params.value === "CONSTRAINT";
          return (
            <div className="flex items-center h-full">
              {isConstrained ? (
                <Badge
                  variant="outline"
                  className="inline-flex items-center gap-1 rounded-full border-red-100 bg-[#fff5f5] px-2.5 py-0.5 text-[10px] font-medium text-red-500 shadow-none border"
                >
                  <ShieldAlert className="h-3 w-3 stroke-[2.5]" /> Constrained
                </Badge>
              ) : (
                <Badge
                  variant="outline"
                  className="inline-flex items-center gap-1 rounded-full border-emerald-100 bg-[#f4fbf7] px-2.5 py-0.5 text-[10px] font-medium text-emerald-600 shadow-none border"
                >
                  <Shield className="h-3 w-3 stroke-[2.5]" /> Clear
                </Badge>
              )}
            </div>
          );
        },
      },
    ],
    []
  );

  const getRowClass = (params: RowClassParams<PesConsolidatedData>) => {
    const base = "transition-colors duration-150 select-none border-b border-slate-100/40 "
    const isConstrained = params.data?.CONSTRAINT === "CONSTRAINT" || params.data?.CONSTRAINT === "CONSTRAINT";
    return isConstrained
      ? `${base} bg-[#fff8f8] hover:bg-[#fdeded]!`
      : `${base} bg-white hover:bg-slate-50/60!`
  }

  const defaultColDef = useMemo<ColDef>(
    () => ({
      sortable: true,
      resizable: true,
      suppressMovable: true,
      headerClass: "text-[11px] font-semibold tracking-tight text-slate-500",
    }),
    []
  )

  const handleFilterChanged = (event: any) => {
    const filterModel = event?.api?.getFilterModel?.() ?? {}
    const custodianFilter = filterModel.CUSTODIAN_NAME

    if (!custodianFilter) {
      onFilterChange?.(null)
      return
    }

    const filterValue =
      typeof custodianFilter.filter === "string"
        ? custodianFilter.filter.trim()
        : Array.isArray(custodianFilter.values)
          ? custodianFilter.values.find((value: unknown) => typeof value === "string" && value.trim())?.trim() ?? null
          : null

    onFilterChange?.(filterValue)
  }

  return (
    <div className="ag-theme-custom-style max-h-[405px] flex w-full flex-col rounded-b-[10px] border border-slate-100 bg-white shadow-[0_12px_24px_-4px_rgba(0,0,0,0.02)]">
      <div style={{ height: "378px", width: "100%" }}>
        <AgGridReact
          theme={customTheme}
          rowData={items}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          getRowClass={getRowClass}
          rowHeight={38}
          headerHeight={36}
          suppressCellFocus={true}
          onRowClicked={(event: any) => onRowClick?.(event.data)}
          onFilterChanged={handleFilterChanged}
        />
      </div>

      <style>{`
        .ag-theme-custom-style .ag-root-wrapper,
        .ag-theme-custom-style .ag-root,
        .ag-theme-custom-style .ag-header,
        .ag-theme-custom-style .ag-row,
        .ag-theme-custom-style .ag-cell {
          border: none !important;
          box-shadow: none !important;
        }

        .ag-theme-custom-style .ag-root-wrapper {
          background: transparent !important;
          overflow: hidden !important;
          border-bottom-left-radius: 10px !important;
          border-bottom-right-radius: 10px !important;
        }

        .ag-theme-custom-style .ag-body-viewport {
          border-bottom-left-radius: 10px !important;
          border-bottom-right-radius: 10px !important;
          overflow-y: auto !important;
        }

        .ag-theme-custom-style .ag-header-row {
          border-bottom: 1px solid #f1f5f9 !important;
        }
      `}</style>
    </div>
  )
}
