import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import type { FilterConstraint, FilterType } from "./types"

export type FilterFocus = "all" | "key"

interface Props {
  search: string
  setSearch: (v: string) => void
  type: FilterType
  setType: (v: FilterType) => void
  constraint: FilterConstraint
  setConstraint: (v: FilterConstraint) => void
  count: number
  total: number
}

export const FilterBar = ({
  search,
  setSearch,
  type,
  setType,
  constraint,
  setConstraint,
  count,
  total,
}: Props) => {
  const typeBtn = (label: FilterType, text: string) => (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setType(label)}
      className={`h-6 rounded-full px-2.5 text-[11px] font-semibold whitespace-nowrap shadow-none ${
        type === label
          ? "border-violet-600 bg-violet-600 text-white hover:bg-violet-700 hover:text-white"
          : "border-slate-200 bg-white text-slate-500 hover:border-blue-300 hover:text-blue-600"
      }`}
    >
      {text}
    </Button>
  )

  const conBtn = (label: FilterConstraint, text: string) => (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setConstraint(label)}
      className={`h-6 rounded-full px-2.5 text-[11px] font-semibold whitespace-nowrap shadow-none ${
        constraint === label
          ? "border-blue-600 bg-blue-600 text-white hover:bg-blue-700 hover:text-white"
          : "border-slate-200 bg-white text-slate-500 hover:border-blue-300 hover:text-blue-600"
      }`}
    >
      {text}
    </Button>
  )

  return (
    <div className="flex shrink-0 items-center gap-2 rounded-t-[8px] border-b border-slate-100 bg-white px-4 py-2">
      <div className="relative">
        <Search className="absolute top-1/2 left-2.5 h-3 w-3 -translate-y-1/2 text-slate-300" />
        <input
          type="text"
          placeholder="Search..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-7 w-48 rounded-full border border-slate-200 bg-white pr-3 pl-7 text-[11px] transition-all placeholder:text-slate-300 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 focus:outline-none"
        />
      </div>

      <div className="mx-0.5 h-4 w-px bg-slate-200"></div>

      <span className="mr-0.5 text-[10px] font-bold tracking-wider text-slate-400 uppercase">
        Type
      </span>
      {typeBtn("ALL", "All AMS")}
      {typeBtn("AMS1", "AMS1")}
      {typeBtn("AMS2", "AMS2")}

      <div className="mx-0.5 h-4 w-px bg-slate-200"></div>

      <span className="mr-0.5 text-[10px] font-bold tracking-wider text-slate-400 uppercase">
        Constraint
      </span>
      {conBtn("ALL", "All")}
      {conBtn("CONSTRAINT", "Constraint")}
      {conBtn("UNCONSTRAINT", "Unconstraint")}

      {/* <label className="ml-2 flex cursor-pointer items-center gap-1.5 select-none">
        <Checkbox
          id="pending-checkbox"
          checked={spPending}
          onCheckedChange={(checked) => setSpPending(!!checked)}
          className="h-3.5 w-3.5 rounded-[3px] border-slate-300 data-[state=checked]:border-amber-500 data-[state=checked]:bg-amber-500"
        />
        <span className="text-[10px] font-bold tracking-wide text-amber-700">
          Action Pending only
        </span>
      </label> */}

      {/* <div className="ml-2 flex items-center gap-2 border-l border-slate-200 pl-2.5">
        <Star 
          className={`h-3 w-3 transition-all duration-300 ${
            focus === "key" 
              ? "fill-amber-400 text-amber-500 drop-shadow-[0_0_4px_rgba(245,158,11,0.5)] scale-110" 
              : "fill-transparent text-slate-300"
          }`} 
        />
        <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">
          Focus
        </span>
        <div className="flex h-6 items-center rounded-full bg-slate-100 p-0.5">
          <button
            type="button"
            onClick={() => setFocus("all")}
            className={`h-5 rounded-full px-2.5 text-[9px] font-black tracking-wider uppercase transition-all duration-150 ${
              focus === "all"
                ? "bg-slate-700 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-600"
            }`}
          >
            All Items
          </button>
          <button
            type="button"
            onClick={() => setFocus("key")}
            className={`h-5 rounded-full px-2.5 text-[9px] font-black tracking-wider uppercase transition-all duration-150 ${
              focus === "key"
                ? "bg-slate-700 text-white shadow-sm"
                : "text-slate-400 hover:text-slate-600"
            }`}
          >
            Key (C1·D1)
          </button>
        </div>
      </div> */}

      <div className="ml-auto font-mono text-[11px] tracking-tight text-slate-400">
        {count}/{total} items
      </div>
    </div>
  )
}
