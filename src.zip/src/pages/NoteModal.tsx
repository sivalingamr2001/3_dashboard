import React, { useEffect, useState } from 'react';
import { MessageSquare, X, Send } from 'lucide-react';

type NoteModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onSave: (note: string) => void;
  initialNote?: string | null;
  title?: string;
  subtitle?: string;
};

const NoteModal: React.FC<NoteModalProps> = ({ isOpen, onClose, onSave, initialNote = '', title, subtitle }) => {
  const [note, setNote] = useState('');

  useEffect(() => {
    if (isOpen) setNote(initialNote ?? '');
  }, [isOpen, initialNote]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (onSave) onSave(note);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm">
      <div className="w-full max-w-[520px] rounded-2xl border border-slate-100 bg-white p-5 shadow-2xl transition-all animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-start justify-between gap-4">
          <div className="flex gap-2.5">
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-violet-50 text-violet-600">
              <MessageSquare size={15} className="fill-violet-100" />
            </div>
            <div className="flex flex-col">
              <h3 className="font-sans text-[15px] font-black tracking-tight text-slate-800 leading-tight">{title || 'Note'}</h3>
              {subtitle && (
                <p className="text-[11px] font-medium text-slate-400 mt-0.5">{subtitle}</p>
              )}
            </div>
          </div>

          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:bg-slate-50 hover:text-slate-600 transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="mt-4">
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Enter your note (visible to Product Custodian when reviewing this commodity item)..."
            rows={4}
            className="w-full resize-none rounded-xl border border-slate-200 bg-white p-3.5 text-[12px] font-medium text-slate-700 placeholder:text-slate-300 outline-none transition-all focus:border-violet-500 focus:ring-2 focus:ring-violet-100"
          />
        </div>

        <div className="mt-4 flex items-center justify-end gap-2 border-t border-slate-50 pt-3">
          <button onClick={onClose} className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-[11px] font-bold text-slate-500 transition-colors hover:bg-slate-50 hover:text-slate-700">Cancel</button>
          <button onClick={handleSave} className="flex items-center gap-1.5 rounded-xl bg-violet-600 px-4 py-2 text-[11px] font-black text-white shadow-sm shadow-violet-200 transition-all hover:bg-violet-700 hover:shadow-none active:scale-[0.98]">
            <Send size={11} className="stroke-[2.5]" />
            Save Note
          </button>
        </div>
      </div>
    </div>
  );
};

export default NoteModal;
