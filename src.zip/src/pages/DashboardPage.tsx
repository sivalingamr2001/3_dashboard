import { useEffect, useCallback, useState } from "react";
import FilterBar from "@/components/FilterBar";
import { StatCards } from "@/components/StateCards";
import ItemTable from "./ItemsTable";
import { useCommodity } from "@/context/CommodityProvider"; // Ensure your folder path matches here

export const DashboardPage = () => {
  // Pull live datasets, aggregations, actions, and load status parameters directly from provider layers
  const {
    commodities,
    dashboardMetrics,
    loading,
    error,
    fetchAllCommodities,
    fetchDashboardMetrics
  } = useCommodity();

  const [activeCustodian, setActiveCustodian] = useState<string | null>(null);
  const [selectedOrg, setSelectedOrg] = useState<number | null>(null);

  // 1. Initial Load of Main Commodities and Summary Cards when active conditions modify
  useEffect(() => {
    fetchAllCommodities();
    fetchDashboardMetrics(activeCustodian, selectedOrg);
  }, [fetchAllCommodities, fetchDashboardMetrics, activeCustodian, selectedOrg]);

  // 2. Custom grid filtering synchronisation loop
  const handleFilterChange = useCallback((custodianName: string | null) => {
    setActiveCustodian(custodianName);
  }, []);

  // 3. Custom Organisation selector changes hook (if your FilterBar triggers top-level org switches)
  const handleOrgChange = useCallback((orgId: number | null) => {
    setSelectedOrg(orgId);
  }, []);

  return (
    <div className="flex w-full flex-col gap-4 p-6 bg-slate-50/50 min-h-screen">
      {/* 1. Statistics Cards Block - Feeds single aggregated record row maps from backend query summaries */}
      <StatCards
        data={dashboardMetrics}
        loading={loading}
      />

      {/* 2. Application Filters Configuration Bar Row */}
      <FilterBar
        activeCustodian={activeCustodian}
        onOrgFilterChange={handleOrgChange}
        totalRows={commodities.length}
        tableData={commodities}
      />

      {/* 3. Core Operational Interface Grid Area Container */}
      <div className="w-full flex flex-col rounded-xl border border-slate-100 bg-white shadow-[0_4px_12px_-2px_rgba(0,0,0,0.03)] overflow-hidden">
        {error ? (
          <div className="flex h-[300px] w-full items-center justify-center p-4 text-center">
            <span className="text-xs font-bold text-red-500 bg-red-50 border border-red-100 px-3 py-1.5 rounded-lg">
              {error}
            </span>
          </div>
        ) : (
          <ItemTable
            items={commodities}
            loading={loading}
            onFilterChange={handleFilterChange}
          />
        )}
      </div>
    </div>
  );
};
