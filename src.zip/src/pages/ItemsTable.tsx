import { commodityApi, type CommodityData } from '@/api/commodityApi';
import ProductModal from '@/components/ProductModal';
import SupplyModal from '@/components/SupplyModal';
import { Badge } from '@/components/ui/badge';
import { themeQuartz, type ColDef, type ColGroupDef, type GridApi, type GridReadyEvent, type ICellRendererParams } from 'ag-grid-community';
import { AgGridReact } from 'ag-grid-react';
import { Eye, TriangleAlert } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

// ---------- Types ----------

type DemandTone = 'fulfilled' | 'current' | 'highlight' | 'projected';

interface GridContext {
  onViewSupply: (row: CommodityData) => void;
  onViewProduct: (row: CommodityData) => void;
}

// ---------- Style & Metric Helper Lookups ----------

const DEMAND_COLOR: Record<DemandTone, string> = {
  fulfilled: 'rgb(217, 119, 6)',     // Amber tracking color
  current: 'rgb(217, 119, 6)',
  highlight: 'rgb(220, 38, 38)',     // Red tracking color
  projected: 'rgb(71, 85, 105)',     // Muted tracking slate color
};

interface DemandParams extends ICellRendererParams<CommodityData, number | null> {
  tone: DemandTone;
}

function DemandCell({ value, tone }: DemandParams) {
  if (value == null) return <span className="text-slate-300 text-xs font-mono font-medium">—</span>;
  return (
    <span className="font-bold text-xs font-mono" style={{ color: DEMAND_COLOR[tone] }}>
      {value.toLocaleString()}
    </span>
  );
}

function SupplyActionCell({ data, context }: ICellRendererParams<CommodityData> & { context: GridContext }) {
  if (!data) return null;
  return (
    <div className="flex items-center justify-center h-full w-full px-1">
      <button
        type="button"
        onClick={() => context.onViewSupply(data)}
        className="text-xs font-bold tracking-wide text-slate-600 bg-slate-50 hover:bg-slate-100 hover:text-slate-800 border border-slate-200 h-[26px] px-2.5 rounded-md flex items-center justify-center gap-1 transition-all w-full"
      >
        <Eye size={12} />
        View
      </button>
    </div>
  );
}

function ProductActionCell({ data, context }: ICellRendererParams<CommodityData> & { context: GridContext }) {
  if (!data) return null;
  return (
    <div className="flex items-center justify-center h-full w-full px-1">
      <button
        type="button"
        onClick={() => context.onViewProduct(data)}
        className="text-xs font-bold tracking-wide text-violet-600 bg-violet-50 hover:bg-violet-100 hover:text-violet-700 border border-violet-200 h-[26px] px-2.5 rounded-md flex items-center justify-center gap-1 transition-all w-full"
      >
        <Eye size={12} />
        View
      </button>
    </div>
  );
}

// ---------- Column Definition Builders ----------

const demandCol = (field: keyof CommodityData, headerName: string, tone: DemandTone): ColDef<CommodityData> => ({
  colId: `demand-${field}`,
  valueGetter: (p) => p.data?.[field] ?? null,
  headerName,
  width: 75,
  cellRenderer: DemandCell,
  cellRendererParams: { tone },
  cellClass: 'text-right font-mono flex items-center justify-end text-xs',
  sortable: true,
  comparator: (a, b) => (a ?? -Infinity) - (b ?? -Infinity),
});

const COLUMN_DEFS: (ColDef<CommodityData> | ColGroupDef<CommodityData>)[] = [
  {
    headerName: 'Org',
    field: 'ORG',
    width: 60,
    suppressSizeToFit: true,
    cellClass: 'flex items-center justify-center font-bold text-slate-700 text-xs' // Fixed text scale size
  },
  {
    headerName: 'Code',
    width: 145,
    field: 'COMPONENT_NO',
    cellClass: 'flex items-center w-full text-xs',
    cellRenderer: (params: any) => {
      if (!params.data) return null;
      return (
        <div className="flex items-center justify-between w-full pr-1">
          <div className="flex items-center gap-1 min-w-0">
            <span className="truncate font-mono font-bold text-violet-700" title={params.value}>
              {params.value?.trim() || <span className="text-slate-300">—</span>}
            </span>
            {params.data.CONSTRAINT_FLAG === 'CONSTRAINT' && (
              <span title="Item supply is currently constrained" className="shrink-0">
                <TriangleAlert size={10} className="text-red-400 fill-red-50" />
              </span>
            )}
          </div>
          <span className="flex justify-center items-center ml-2 text-[10px] h-4 text-slate-400 font-sans font-semibold uppercase shrink-0 bg-slate-50 border border-slate-200 px-1 rounded">
            {params.data.UOM || '—'}
          </span>
        </div>
      );
    }
  },
  {
    headerName: 'Description',
    field: 'DESCRIPTION',
    minWidth: 170,
    flex: 1,
    cellClass: 'flex items-center text-slate-700 text-xs font-medium'
  },
  {
    headerName: 'MONTHLY DEMAND (UNITS)',
    headerClass: 'text-center font-bold border-l border-r border-slate-100',
    children: [
      demandCol('LAST_MONTH', "Jun'26", 'current'),
      demandCol('THIS_MONTH', "Jul'26", 'highlight'),
      demandCol('MONTH_PLUS_ONE', "Aug'26", 'projected'),
      demandCol('MONTH_PLUS_TWO_ONWARDS', "Sep'26+", 'projected'),
    ],
  },
  {
    headerName: "Constraint",
    field: "CONSTRAINT_FLAG",
    width: 100,
    cellRenderer: (params: any) => {
      const isConstrained = params.value === "CONSTRAINT";
      return (
        <div className="flex items-center h-full">
          {isConstrained ? (
            <Badge
              variant="outline"
              className="inline-flex items-center gap-1 rounded-full border-red-100 bg-[#fff5f5] px-2 py-0.5 text-[10px] font-bold text-red-500 shadow-none border"
            >
              Constrained
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="inline-flex items-center gap-1 rounded-full border-emerald-100 bg-[#f4fbf7] px-2 py-0.5 text-[10px] font-bold text-emerald-600 shadow-none border"
            >
              Clear
            </Badge>
          )}
        </div>
      );
    },
  },
  {
    headerName: 'Vendor Cat',
    field: 'VENDOR_CATEGORY',
    width: 120,
    cellClass: 'flex items-center text-slate-600 text-left text-xs'
  },
  {
    headerName: 'Custodian',
    field: 'CUSTODIAN_NAME',
    width: 110,
    cellClass: 'flex items-center text-slate-600 text-left truncate text-xs',
    valueFormatter: (p) => p.value || 'Unassigned'
  },
  {
    headerName: 'CMG',
    field: 'CMG_FLAG',
    width: 55,
    cellClass: 'flex items-center justify-center font-mono text-xs',
    valueFormatter: (p) => p.value || '—'
  },
  {
    headerName: 'Supplies',
    colId: 'col-supplies',
    width: 80,
    suppressSizeToFit: true,
    cellRenderer: SupplyActionCell,
    sortable: false,
    filter: false
  },
  {
    headerName: 'Products',
    colId: 'col-products',
    width: 80,
    suppressSizeToFit: true,
    cellRenderer: ProductActionCell,
    sortable: false,
    filter: false
  },
];

const DEFAULT_COL_DEF: ColDef<CommodityData> = {
  resizable: true,
  suppressMovable: true,
  wrapHeaderText: true,
  autoHeaderHeight: true,
  cellClass: 'text-xs',
  headerClass: 'text-xs font-semibold text-slate-700'
};

// ---------- Main Component ----------

interface ItemTableProps {
  onViewSupplyDetails?: (item: CommodityData) => void;
  onViewProductDetails?: (item: CommodityData) => void;
}

export default function ItemTable({ onViewSupplyDetails, onViewProductDetails }: ItemTableProps) {
  const gridApiRef = useRef<GridApi<CommodityData> | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [modalItem, setModalItem] = useState<CommodityData | null>(null);

  const [productModalOpen, setProductModalOpen] = useState(false);
  const [productModalItem, setProductModalItem] = useState<CommodityData | null>(null);


  const [rowData, setRowData] = useState<CommodityData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const data: any = await commodityApi.getAllCommodities();
        setRowData(data.data || []);
      } catch (err) {
        console.error('Error fetching commodity data:', err);
        setError('Failed to load commodity data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleViewProduct = useCallback((row: CommodityData) => {
    // Open the new product linkages tracking layout frame
    setProductModalItem(row);
    setProductModalOpen(true);
    if (onViewProductDetails) onViewProductDetails(row);
  }, [onViewProductDetails]);

  const handleViewSupply = useCallback((row: CommodityData) => {
    setModalItem(row);
    setModalOpen(true);
    if (onViewSupplyDetails) onViewSupplyDetails(row);
  }, [onViewSupplyDetails]);

  const context: GridContext = useMemo(
    () => ({ onViewSupply: handleViewSupply, onViewProduct: handleViewProduct }),
    [handleViewSupply, handleViewProduct],
  );

  const handleGridReady = useCallback((e: GridReadyEvent<CommodityData>) => {
    gridApiRef.current = e.api;
  }, []);

  if (loading) {
    return (
      <div className="h-screen flex w-full flex-col min-h-0">
        <div className="flex-1 min-h-0 flex items-center justify-center border border-slate-100 bg-white rounded-b-[8px]">
          <span className="text-xs font-semibold text-slate-400 animate-pulse">Loading commodity view metrics...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-screen flex w-full flex-col min-h-0">
        <div className="flex-1 min-h-0 flex items-center justify-center border border-red-100 bg-red-50 rounded-b-[8px] p-3 text-center">
          <span className="text-xs font-bold text-red-600">{error}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex w-full flex-col min-h-0">
      <div className="ag-theme-custom-style flex-1 min-h-0 w-full flex flex-col text-xs rounded-none border border-slate-100 bg-white shadow-[0_12px_24px_-4px_rgba(0,0,0,0.02)]">
        <div className="h-[505px] w-full">
          <AgGridReact<CommodityData>
            rowData={rowData}
            columnDefs={COLUMN_DEFS}
            defaultColDef={DEFAULT_COL_DEF}
            context={context}
            getRowId={(p) => String(p.data.COMPONENT_ITEM_ID)}
            headerHeight={34}
            groupHeaderHeight={26}
            rowHeight={38}
            onGridReady={handleGridReady}
            suppressCellFocus
            animateRows
            theme={themeQuartz}
          />
        </div>
      </div>
      <SupplyModal
        open={modalOpen}
        organizationId={modalItem?.ORGANIZATION_ID ?? null} // Fixed attribute lookup
        itemNo={modalItem?.COMPONENT_NO ?? null}
        onClose={() => setModalOpen(false)}
      />
      <ProductModal
        open={productModalOpen}
        organizationId={productModalItem?.ORGANIZATION_ID ?? null}
        organization={productModalItem?.ORG ?? null}
        itemNo={productModalItem?.COMPONENT_NO ?? null}
        onClose={() => {
          setProductModalOpen(false);
          setProductModalItem(null);
        }}
      />
    </div>
  );
}
