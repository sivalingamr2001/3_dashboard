import type { CommodityData } from "@/api/commodityApi";
import { Building2, ChevronDown, Factory, Search, ShieldAlert } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

interface FilterBarProps {
  activeCustodian: string | null;
  onOrgFilterChange: (orgId: number | null) => void;
  totalRows: number;
  tableData: CommodityData[]; // Added prop to extract live organization combinations
}

export default function FilterBar({ activeCustodian, onOrgFilterChange, totalRows, tableData }: FilterBarProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectedOrgLabel, setSelectedOrgLabel] = useState("All Orgs");
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Dynamically compute unique Orgs from live table data safely
  // Dynamically compute unique Orgs from live table data safely in Ascending order
  const orgOptions = useMemo(() => {
    const uniqueMap = new Map<number | null, string>();

    tableData.forEach((row) => {
      const orgId = (row as any).ORGANIZATION_ID;
      const orgCode = (row as any).ORG;

      if (orgId != null && orgCode) {
        uniqueMap.set(Number(orgId), `${orgCode.trim()}`);
      }
    });

    // 1. Convert entries to array and sort them alphabetically/numerically by label text
    const sortedOptions = Array.from(uniqueMap.entries())
      .map(([id, label]) => ({ id, label }))
      .sort((a, b) => a.label.localeCompare(b.label, undefined, { numeric: true, sensitivity: 'base' }));

    // 2. Unshift the fixed global "All Orgs" baseline selection to the very top position
    return [{ id: null, label: "All Orgs" }, ...sortedOptions];
  }, [tableData]);


  // Sync selected label text layout if active options shift or drop off
  useEffect(() => {
    const match = orgOptions.find(opt => opt.label === selectedOrgLabel);
    if (!match && selectedOrgLabel !== "All Orgs") {
      setSelectedOrgLabel("All Orgs");
      onOrgFilterChange(null);
    }
  }, [orgOptions, selectedOrgLabel, onOrgFilterChange]);

  // Close dropdown when clicking anywhere outside of element boundaries
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleOrgSelect = (orgId: number | null, label: string) => {
    setSelectedOrgLabel(label);
    onOrgFilterChange(orgId);
    setDropdownOpen(false);
  };

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-100 rounded-xl shrink-0 flex-wrap shadow-[0_2px_8px_-3px_rgba(0,0,0,0.02)] select-none">

      {/* Dynamic Organization Dropdown Selector */}
      <div className="relative" ref={dropdownRef}>
        <button
          type="button"
          onClick={() => setDropdownOpen(!dropdownOpen)}
          className="flex items-center gap-1.5 text-xs font-bold border border-slate-200 rounded-lg px-2.5 py-1 bg-white hover:border-violet-400 transition-colors min-w-[130px] text-slate-700"
        >
          <Building2 size={12} className="text-violet-500 shrink-0" />
          <span className="truncate">{selectedOrgLabel}</span>
          <ChevronDown size={11} className="ml-auto text-slate-400 shrink-0" />
        </button>

        {dropdownOpen && (
          <div className="absolute left-0 mt-1 w-48 bg-white border border-slate-100 shadow-lg rounded-lg py-1 z-30 font-sans text-xs max-h-56 overflow-y-auto">
            {orgOptions.map((org) => (
              <button
                key={org.id ?? "all"}
                type="button"
                onClick={() => handleOrgSelect(org.id, org.label)}
                className={`w-full text-left px-3 py-1.5 font-medium hover:bg-slate-50 transition-colors block ${selectedOrgLabel === org.label ? "text-violet-600 bg-violet-50/50 font-bold" : "text-slate-600"
                  }`}
              >
                {org.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="w-px h-4 bg-slate-200" />

      <div className="relative">
        <button className="flex items-center gap-1.5 text-xs font-bold border border-slate-200 rounded-lg px-2.5 py-1 bg-white hover:border-violet-400 transition-colors min-w-[140px]">
          <Factory size={12} className="text-indigo-500 shrink-0" />
          <span className="text-slate-400">All Products</span>
          <ChevronDown size={11} className="ml-auto text-slate-400" />
        </button>
      </div>

      <div className="w-px h-4 bg-slate-200" />

      <button className="text-xs font-bold px-2.5 py-1 rounded-lg border transition-all bg-slate-700 text-white border-slate-700">All Tags</button>
      <button className="text-xs font-bold px-2.5 py-1 rounded-lg border transition-all text-slate-500 border-slate-200 hover:border-slate-400 bg-white">T1a</button>
      <button className="text-xs font-bold px-2.5 py-1 rounded-lg border transition-all text-slate-500 border-slate-200 hover:border-slate-400 bg-white">T1b</button>
      <button className="text-xs font-bold px-2.5 py-1 rounded-lg border transition-all text-slate-500 border-slate-200 hover:border-slate-400 bg-white">T2</button>

      <button className="flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg border transition-all text-red-500 border-red-200 bg-red-50 hover:border-red-400">
        <ShieldAlert size={11} />
        Constrained
      </button>

      <div className="ml-auto flex items-center gap-1.5">
        <Search size={12} className="text-slate-400" />
        <input
          placeholder="Code / desc…"
          className="text-xs border border-slate-200 rounded-lg px-2.5 py-1 w-32 focus:outline-none focus:border-violet-400 bg-slate-50"
          defaultValue=""
        />
      </div>

      <span className="text-xs text-slate-400 font-semibold shrink-0 pl-1">
        {totalRows.toLocaleString()} items
      </span>
    </div>
  );
}
