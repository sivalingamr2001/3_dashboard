import React from 'react';
import type { DashboardConsolidatedMetrics } from '@/api/commodityApi';

interface StatCardsProps {
    data: DashboardConsolidatedMetrics | null;
    loading?: boolean;
}

export const StatCards: React.FC<StatCardsProps> = ({ data, loading }) => {
    
    // Skeleton loader layout fallback while the API aggregation subquery executes
    if (loading || !data) {
        return (
            <div className="flex w-full items-stretch justify-between gap-2 font-sans animate-pulse">
                {[1, 2, 3].map((key) => (
                    <div key={key} className="flex-1 bg-slate-100/50 border border-slate-200 shadow-sm rounded-lg h-[82px] min-w-[140px]" />
                ))}
            </div>
        );
    }

    return (
        <div className="flex w-full items-stretch justify-between gap-2 font-sans select-none">

            {/* Card 1: T1a (Track 1a) */}
            <div className="flex-1 bg-white border border-gray-100 shadow-sm rounded-lg p-2 flex flex-col justify-between min-w-[140px]">
                <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-red-500"></span>
                        <span className="px-2 py-0.5 font-bold text-xs text-red-600 bg-red-50 border border-red-100 rounded-md">T1a</span>
                    </div>
                    <span className="text-xs font-bold text-slate-800">
                        {(data.TOTAL_TRACK_1A ?? 0).toLocaleString()}
                    </span>
                </div>
                <div className="mt-2 text-xs space-y-1">
                    <div className="flex items-center justify-start gap-1 font-semibold text-red-600">
                        <span>📦</span> {(data.SHORTAGE_TRACK_1A ?? 0).toLocaleString()} shortage
                    </div>
                    <div className="flex items-center justify-start gap-1 font-semibold text-amber-600">
                        <span>🕒</span> {(data.OVERDUE_TRACK_1A ?? 0).toLocaleString()} Pending Overdue
                    </div>
                </div>
            </div>

            {/* Card 2: T1b (Track 1b) */}
            <div className="flex-1 bg-white border border-gray-100 shadow-sm rounded-lg p-2 flex flex-col justify-between min-w-[140px]">
                <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                        <span className="px-2 py-0.5 font-bold text-xs text-amber-600 bg-amber-50 border border-amber-100 rounded-md">T1b</span>
                    </div>
                    <span className="text-xs font-bold text-slate-800">
                        {(data.TOTAL_TRACK_1B ?? 0).toLocaleString()}
                    </span>
                </div>
                <div className="mt-2 text-xs space-y-1">
                    <div className="flex items-center justify-start gap-1 font-semibold text-red-600">
                        <span>📦</span> {(data.SHORTAGE_TRACK_1B ?? 0).toLocaleString()} shortage
                    </div>
                    <div className="flex items-center justify-start gap-1 font-semibold text-amber-600">
                        <span>🕒</span> {(data.OVERDUE_TRACK_1B ?? 0).toLocaleString()} Pending Overdue
                    </div>
                </div>
            </div>

            {/* Card 3: T2 (Track 2) */}
            <div className="flex-1 bg-white border border-gray-100 shadow-sm rounded-lg p-2 flex flex-col justify-between min-w-[140px]">
                <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                        <span className="px-2 py-0.5 font-bold text-xs text-slate-600 bg-slate-50 border border-slate-100 rounded-md">T2</span>
                    </div>
                    <span className="text-xs font-bold text-slate-800">
                        {(data.TOTAL_TRACK_2 ?? 0).toLocaleString()}
                    </span>
                </div>
                <div className="mt-2 text-xs space-y-1">
                    <div className="flex items-center justify-start gap-1 font-semibold text-emerald-600">
                        <span>📦</span> {data.SHORTAGE_TRACK_2 === 0 ? 'stock OK' : `${(data.SHORTAGE_TRACK_2 ?? 0).toLocaleString()} shortage`}
                    </div>
                    <div className="flex items-center justify-start gap-1 font-semibold text-slate-400">
                        <span>🕒</span> {data.OVERDUE_TRACK_2 === 0 ? 'on sched' : `${(data.OVERDUE_TRACK_2 ?? 0).toLocaleString()} Pending Overdue`}
                    </div>
                </div>
            </div>

        </div>
    );
};
